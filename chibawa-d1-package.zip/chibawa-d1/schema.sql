-- Run once against your Cloudflare D1 database.
CREATE TABLE IF NOT EXISTS site_stats (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  visits INTEGER NOT NULL DEFAULT 0
);

INSERT OR IGNORE INTO site_stats (id, visits) VALUES (1, 0);

CREATE TABLE IF NOT EXISTS guestbook (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 32),
  message TEXT NOT NULL CHECK (length(message) BETWEEN 1 AND 240),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_guestbook_created ON guestbook(id DESC);
