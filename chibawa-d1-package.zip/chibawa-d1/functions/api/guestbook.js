function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
}

function sameOrigin(request) {
  const origin = request.headers.get('Origin');
  if (!origin) return true;
  try { return new URL(origin).host === new URL(request.url).host; }
  catch { return false; }
}

export async function onRequestGet({ env }) {
  if (!env.DB) return json({ error: 'D1 binding DB is not configured.' }, 503);
  try {
    const result = await env.DB.prepare(
      'SELECT id, name, message, created_at FROM guestbook ORDER BY id DESC LIMIT 50'
    ).all();
    return json({ notes: result.results || [] });
  } catch {
    return json({ error: 'The guestbook is temporarily unavailable.' }, 500);
  }
}

export async function onRequestPost({ request, env }) {
  if (!sameOrigin(request)) return json({ error: 'Cross-origin requests are not allowed.' }, 403);
  if (!env.DB) return json({ error: 'D1 binding DB is not configured.' }, 503);
  const length = Number(request.headers.get('Content-Length') || 0);
  if (length > 4096) return json({ error: 'Message is too large.' }, 413);
  let body;
  try { body = await request.json(); }
  catch { return json({ error: 'Please send valid JSON.' }, 400); }
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const message = typeof body.message === 'string' ? body.message.trim() : '';
  if (!name || name.length > 32 || !message || message.length > 240) {
    return json({ error: 'Name must be 1–32 characters and message 1–240 characters.' }, 400);
  }
  try {
    const note = await env.DB.prepare(
      'INSERT INTO guestbook (name, message) VALUES (?, ?) RETURNING id, name, message, created_at'
    ).bind(name, message).first();
    return json({ note }, 201);
  } catch {
    return json({ error: 'Your note could not be saved. Please try again.' }, 500);
  }
}
