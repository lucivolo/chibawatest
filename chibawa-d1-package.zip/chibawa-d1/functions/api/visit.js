function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
}

export async function onRequestPost({ request, env }) {
  const origin = request.headers.get('Origin');
  if (origin) {
    try { if (new URL(origin).host !== new URL(request.url).host) return json({ error: 'Cross-origin requests are not allowed.' }, 403); }
    catch { return json({ error: 'Invalid origin.' }, 403); }
  }
  if (!env.DB) return json({ error: 'D1 binding DB is not configured.' }, 503);
  try {
    const row = await env.DB.prepare(
      'INSERT INTO site_stats (id, visits) VALUES (1, 1) ON CONFLICT(id) DO UPDATE SET visits = visits + 1 RETURNING visits'
    ).first();
    return json({ visits: row.visits });
  } catch {
    return json({ error: 'The visitor counter is temporarily unavailable.' }, 500);
  }
}
