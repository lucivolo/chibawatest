CHIBAWA — SHARED VISITOR COUNTER + GUESTBOOK

Files in this package:
- index.html              Updated website (all original embedded image data retained)
- functions/api/visit.js  Cloudflare Pages Function for the global visit counter
- functions/api/guestbook.js  Cloudflare Pages Function for shared guestbook
- schema.sql              D1 database tables

DEPLOYMENT (Cloudflare Pages + D1)

1. Create the database
   - Open the Cloudflare dashboard.
   - Go to Storage & databases > D1 SQL Database.
   - Create a database named: chibawa-db

2. Create the tables
   - Open the new D1 database and its Console.
   - Copy the complete contents of schema.sql into the SQL console.
   - Execute it. It creates the visitor counter and guestbook tables.

3. Bind D1 to your Pages project
   - Open Workers & Pages > your Chibawa Pages project.
   - Open Settings > Functions (sometimes shown under Settings > Bindings).
   - Add a D1 database binding:
       Variable name: DB
       D1 database: chibawa-db
   - Save the binding.

4. Put the files in the GitHub repository
   - Replace the site's homepage with this package's index.html.
   - Add the entire functions folder at the repository root, alongside index.html.
   - Add schema.sql if you want to keep the database setup script in the repo.
   - Commit and push. Cloudflare Pages should deploy the static site and Functions together.

5. Verify after deployment
   - Open https://YOUR-SITE.example/api/guestbook
     Expected: {"notes":[]} (or a list of saved notes).
   - Load the homepage in two different browsers/devices. The visit count should
     increase globally.
   - Post a test guestbook note. Refresh on another device; it should appear there.

IMPORTANT
- The API paths are same-origin: /api/visit and /api/guestbook.
- The browser code keeps localStorage as an offline fallback if the API is not
  deployed or the D1 binding is missing. In that case the counter explicitly
  says "visits on this device" and local notes are labeled as local.
- Guestbook notes are public and visible to every visitor. Ask visitors not to
  post phone numbers, addresses, passwords, or other private information.
- Basic input validation and same-origin checks are included. Before sharing the
  site widely, add a Cloudflare WAF rate-limiting rule for POST /api/guestbook to
  reduce spam/abuse. Do not put secret API keys in index.html.
- The global counter counts each page load that reaches /api/visit; it is not a
  unique-human analytics count and may include refreshes and automated traffic.
